# Moved to mobile-native

This repo has now moved to [Minds/mobile-native](https://github.com/Minds/mobile-native)
